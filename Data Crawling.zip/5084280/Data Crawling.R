library(twitteR)
library(rtweet)
library(tidyverse)
library(tm)

create_token(
  app             = "my_twitter_research_app",
  consumer_key    = 'xNkNrYjOVqpenmDZO2uB9gE5K',
  consumer_secret = 'TGfPUpFq2PBQVRApbgSqfXK0twkCjoGlaWTssM8JlKoNXGFvoI',
  access_token    = '1061919402277433345-IQ6HyGoSk3kFg7WU1mCn4daeswlaws',
  access_secret   = 'k4VFAgAiN6fFHrXEUmwzREZvpZGubW4ySvW1nqXJlpGfE')

JNE <- search_tweets("JNECare", lang="id", n=500, 
                     tweet_mode="extended", include_rts=FALSE)
JNECRAW <- data.frame(JNE$created_at, JNE$full_text, JNE$display_text_range,
                      as.character(JNE$in_reply_to_screen_name))
write.csv(JNECRAW, file="dataset_klaster.csv")
